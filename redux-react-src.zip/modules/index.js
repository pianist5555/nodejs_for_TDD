import { combineReducers } from "redux";
import counter from './counter';
import todos from "./todos";

const rootReducer = combineReducers({ // 1개의 프로젝트에 1개의 리듀서를 위한 모음 처리 , createStore(rootReducer)
    counter,
    todos,
});

export default rootReducer // 파일 이름이 index.js이기 때문에 디렉터리 이름까지만 입력하여 불러올 수 있음 