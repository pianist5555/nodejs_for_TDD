import { createAction, handleActions } from 'redux-actions';

const INCREASE = 'counter/INCREASE'; // 프로젝트가 커졌을때 모듈 구분을 위한 액션 타입이름 (모듈/타입)
const DECREASE = 'counter/DECREASE';

export const increase = () => ({type: INCREASE}); // 액션 생성함수
export const decrease = createAction(DECREASE); // redux-actions 모듈 사용 -> 액션 생성함수

const initialState = { // 초기 값 and 객체 key 생성 ( counterContainer의 props를 받기 위한)
    number: 2
};

const counter = handleActions(
    {
        [INCREASE]: (state, action) => ({ number: state.number + 1 }),
        [DECREASE]: (state, action) => ({ number: state.number - 1 }),
    },
    initialState,
)

// redux-actions 모듈 사용전 case 문으로 만든 리듀서 객체
// function counter(state = initialState, action) { // 리듀서 객체
//     switch (action.type) {
//         case INCREASE:
//             return {
//                 number: state.number + 1
//             };
//         case DECREASE:
//             return {
//                 number: state.number - 1
//             };
//         default:
//             return state;
//     }
// }

export default counter;