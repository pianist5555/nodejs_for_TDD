import React from 'react';
import { connect } from 'react-redux';
import Counter from '../components/Counter';
import { increase, decrease} from '../modules/counter';

const CounterContainer = ({ number, increase, decrease }) => {
    return <Counter  number={number} onIncrease={increase} onDecrease={decrease} />
};

export default connect ( // connect 함수안에 state 객체와, 함수 객체를 CounterContainer가 받아 Counter components에 전달
    state => ({ // createStore -> rootReducer에서 counter reducer안의 number를 state로 가지고옴
        number: state.counter.number,
    }),
    {
        increase,
        decrease,
    },
)(CounterContainer);

// [ 생략전 상태]
// const mapStateToProps = state => ({ // 현재 상태
//     number: state.counter.number,
// });
// const mapDispatchToProps = dispatch => ({ // dispatch
//     increase: () => {
//         dispatch(increase());
//     },
//     decrease: () => {
//         dispatch(decrease());
//     },
// });
// const connected = connect(mapStateToProps,mapDispatchToProps)

// export default connected(CounterContainer);